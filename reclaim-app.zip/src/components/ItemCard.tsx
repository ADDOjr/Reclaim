import { Link } from 'react-router-dom';
import { MapPin, Calendar, Tag, Package } from 'lucide-react';
import type { Item } from '@/types';

interface ItemCardProps {
  item: Item;
  matchScore?: number;
  showStatus?: boolean;
}

export default function ItemCard({ item, matchScore, showStatus }: ItemCardProps) {
  const photo = item.photo_urls?.[0];
  const typeLabel = item.type === 'lost' ? 'Lost' : 'Found';
  const typeColor = item.type === 'lost' ? 'bg-red-100 text-red-700' : 'bg-emerald-100 text-emerald-700';

  return (
    <Link
      to={`/app/item/${item.id}`}
      className="group block rounded-2xl border border-gray-200 bg-white overflow-hidden hover:shadow-lg hover:border-gray-300 transition-all"
    >
      <div className="aspect-[4/3] bg-gray-100 relative overflow-hidden">
        {photo ? (
          <img
            src={photo}
            alt={item.title}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center">
            <Package className="w-12 h-12 text-gray-300" />
          </div>
        )}
        <div className="absolute top-3 left-3 flex gap-2">
          <span className={`px-3 py-1 rounded-full text-xs font-semibold ${typeColor}`}>
            {typeLabel}
          </span>
          {showStatus && item.status === 'resolved' && (
            <span className="px-3 py-1 rounded-full text-xs font-semibold bg-slate-900 text-white">
              Resolved
            </span>
          )}
        </div>
        {matchScore !== undefined && (
          <div className="absolute top-3 right-3">
            <div className={`px-3 py-1 rounded-full text-xs font-bold ${
              matchScore >= 85 ? 'bg-emerald-500 text-white' :
              matchScore >= 70 ? 'bg-green-500 text-white' :
              matchScore >= 50 ? 'bg-amber-500 text-white' :
              'bg-gray-500 text-white'
            }`}>
              {matchScore}% match
            </div>
          </div>
        )}
      </div>
      <div className="p-5">
        <h3 className="font-bold text-slate-900 text-lg mb-1 group-hover:text-emerald-600 transition-colors">
          {item.title}
        </h3>
        <div className="flex items-center gap-3 text-sm text-slate-500 mb-3">
          <span className="flex items-center gap-1">
            <Tag className="w-3.5 h-3.5" />
            {item.category}
          </span>
          <span>{item.color}</span>
          {item.brand && <span className="truncate">· {item.brand}</span>}
        </div>
        <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-slate-400">
          <span className="flex items-center gap-1">
            <MapPin className="w-3.5 h-3.5" />
            {item.location}
          </span>
          {item.building && (
            <span className="flex items-center gap-1">
              <Calendar className="w-3.5 h-3.5" />
              {item.building}
            </span>
          )}
          <span className="flex items-center gap-1">
            <Calendar className="w-3.5 h-3.5" />
            {new Date(item.date_event).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}
          </span>
        </div>
      </div>
    </Link>
  );
}
