import { Link } from 'react-router-dom';
import { Search, Sparkles, Camera, MapPin, ArrowRight, Shield, Zap, Users, CheckCircle2 } from 'lucide-react';

export default function LandingPage() {
  return (
    <div className="min-h-screen bg-white">
      {/* Nav */}
      <nav className="fixed top-0 left-0 right-0 z-40 bg-white/80 backdrop-blur-md border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-slate-900 flex items-center justify-center">
              <Search className="w-5 h-5 text-white" />
            </div>
            <span className="text-xl font-bold text-slate-900">Reclaim</span>
          </div>
          <div className="flex items-center gap-3">
            <Link to="/login" className="px-4 py-2 text-sm font-medium text-slate-700 hover:text-slate-900">
              Sign in
            </Link>
            <Link
              to="/signup"
              className="px-5 py-2 rounded-lg bg-slate-900 text-white text-sm font-semibold hover:bg-slate-800 transition-colors"
            >
              Get started
            </Link>
          </div>
        </div>
      </nav>

      {/* Hero */}
      <section className="pt-32 pb-20 px-6 relative overflow-hidden">
        <div className="absolute inset-0 -z-10">
          <div className="absolute top-0 left-1/4 w-96 h-96 bg-emerald-100 rounded-full blur-3xl opacity-60" />
          <div className="absolute top-40 right-1/4 w-96 h-96 bg-blue-100 rounded-full blur-3xl opacity-60" />
        </div>
        <div className="max-w-4xl mx-auto text-center">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-emerald-50 border border-emerald-200 text-emerald-700 text-sm font-medium mb-6">
            <Sparkles className="w-4 h-4" />
            AI-powered matching
          </div>
          <h1 className="text-5xl md:text-6xl font-bold text-slate-900 leading-tight tracking-tight mb-6">
            Lost something?<br />
            <span className="bg-gradient-to-r from-emerald-600 to-blue-600 bg-clip-text text-transparent">
              Let's find it together.
            </span>
          </h1>
          <p className="text-xl text-slate-600 max-w-2xl mx-auto mb-10 leading-relaxed">
            Report lost and found items in seconds. Our smart matching system compares category, color, brand, keywords, photos, date and location to connect you with the right match automatically.
          </p>
          <div className="flex items-center justify-center gap-4 flex-wrap">
            <Link
              to="/signup"
              className="px-7 py-3.5 rounded-xl bg-slate-900 text-white font-semibold hover:bg-slate-800 transition-colors flex items-center gap-2 group"
            >
              Start for free
              <ArrowRight className="w-4 h-4 group-hover:translate-x-0.5 transition-transform" />
            </Link>
            <Link
              to="/login"
              className="px-7 py-3.5 rounded-xl border border-gray-200 text-slate-700 font-semibold hover:bg-gray-50 transition-colors"
            >
              Sign in
            </Link>
          </div>
        </div>
      </section>

      {/* Match demo */}
      <section className="px-6 pb-20">
        <div className="max-w-5xl mx-auto">
          <p className="text-center text-sm font-medium text-slate-500 uppercase tracking-wider mb-6">
            How matching works
          </p>
          <div className="grid md:grid-cols-3 gap-4">
            {[
              { lost: 'Black HP Laptop', found: 'Black HP Laptop', score: 98, color: 'emerald' },
              { lost: 'Blue Backpack', found: 'Navy Backpack', score: 90, color: 'green' },
              { lost: 'iPhone 13', found: 'Samsung Phone', score: 15, color: 'red' },
            ].map((m) => (
              <div key={m.lost} className="rounded-2xl border border-gray-200 bg-white p-6 shadow-sm hover:shadow-md transition-shadow">
                <div className="flex items-center justify-between gap-3 mb-4">
                  <div className="flex-1">
                    <p className="text-xs text-slate-400 mb-1">Lost</p>
                    <p className="font-semibold text-slate-900 text-sm">{m.lost}</p>
                  </div>
                  <div className="text-2xl font-bold text-slate-300">→</div>
                  <div className="flex-1">
                    <p className="text-xs text-slate-400 mb-1">Found</p>
                    <p className="font-semibold text-slate-900 text-sm">{m.found}</p>
                  </div>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium text-slate-600">Match score</span>
                  <span className={`text-2xl font-bold ${
                    m.color === 'emerald' ? 'text-emerald-600' :
                    m.color === 'green' ? 'text-green-600' : 'text-red-500'
                  }`}>
                    {m.score}%
                  </span>
                </div>
                <div className="mt-2 h-2 rounded-full bg-gray-100 overflow-hidden">
                  <div
                    className={`h-full rounded-full ${
                      m.color === 'emerald' ? 'bg-emerald-500' :
                      m.color === 'green' ? 'bg-green-500' : 'bg-red-400'
                    }`}
                    style={{ width: `${m.score}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="px-6 py-20 bg-gray-50">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-14">
            <h2 className="text-3xl md:text-4xl font-bold text-slate-900 mb-4">Everything you need to reclaim what's lost</h2>
            <p className="text-lg text-slate-600 max-w-2xl mx-auto">
              From reporting to matching, we've built the tools that bring lost items home.
            </p>
          </div>
          <div className="grid md:grid-cols-3 gap-6">
            {[
              { icon: Camera, title: 'Photo uploads', desc: 'Add multiple photos to your reports so others can visually confirm matches.' },
              { icon: Sparkles, title: 'AI matching', desc: 'Our algorithm compares six factors and gives every pair a similarity score.' },
              { icon: MapPin, title: 'Location tracking', desc: 'Pinpoint where items were lost or found to surface nearby matches first.' },
              { icon: Zap, title: 'Instant alerts', desc: 'Get notified the moment a found item matches something you reported lost.' },
              { icon: Shield, title: 'Secure accounts', desc: 'Your reports are tied to your account. Only you can edit or resolve them.' },
              { icon: Users, title: 'Community driven', desc: 'Everyone contributes. The more reports, the better the matches.' },
            ].map((f) => (
              <div key={f.title} className="rounded-2xl bg-white border border-gray-200 p-6 hover:shadow-lg transition-shadow">
                <div className="w-12 h-12 rounded-xl bg-slate-900 flex items-center justify-center mb-4">
                  <f.icon className="w-6 h-6 text-white" />
                </div>
                <h3 className="text-lg font-bold text-slate-900 mb-2">{f.title}</h3>
                <p className="text-slate-600 leading-relaxed">{f.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="px-6 py-20">
        <div className="max-w-4xl mx-auto rounded-3xl bg-slate-900 p-12 text-center relative overflow-hidden">
          <div className="absolute inset-0 opacity-20">
            <div className="absolute top-0 left-0 w-72 h-72 bg-emerald-500 rounded-full blur-3xl" />
            <div className="absolute bottom-0 right-0 w-72 h-72 bg-blue-500 rounded-full blur-3xl" />
          </div>
          <div className="relative z-10">
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">Ready to find what you lost?</h2>
            <p className="text-slate-300 text-lg mb-8 max-w-xl mx-auto">
              Join Reclaim today. It's free, fast, and your next match could be one report away.
            </p>
            <Link
              to="/signup"
              className="inline-flex items-center gap-2 px-7 py-3.5 rounded-xl bg-emerald-500 text-white font-semibold hover:bg-emerald-600 transition-colors group"
            >
              Create your account
              <ArrowRight className="w-4 h-4 group-hover:translate-x-0.5 transition-transform" />
            </Link>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="px-6 py-10 border-t border-gray-100">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-slate-900 flex items-center justify-center">
              <Search className="w-4 h-4 text-white" />
            </div>
            <span className="font-bold text-slate-900">Reclaim</span>
          </div>
          <p className="text-sm text-slate-500">Helping people reunite with what they've lost.</p>
        </div>
      </footer>
    </div>
  );
}
