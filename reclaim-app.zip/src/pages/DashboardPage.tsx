import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Plus, Search, Package, TrendingUp, Sparkles, AlertCircle } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import type { Item } from '@/types';
import ItemCard from '@/components/ItemCard';

export default function DashboardPage() {
  const { user } = useAuth();
  const [items, setItems] = useState<Item[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function load() {
      if (!user) return;
      const { data } = await supabase
        .from('items')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });
      setItems((data as Item[]) ?? []);
      setLoading(false);
    }
    load();
  }, [user]);

  const lostItems = items.filter((i) => i.type === 'lost');
  const foundItems = items.filter((i) => i.type === 'found');
  const resolvedItems = items.filter((i) => i.status === 'resolved');

  const stats = [
    { label: 'Items reported', value: items.length, icon: Package, color: 'bg-blue-50 text-blue-600' },
    { label: 'Lost items', value: lostItems.length, icon: AlertCircle, color: 'bg-red-50 text-red-600' },
    { label: 'Found items', value: foundItems.length, icon: Search, color: 'bg-emerald-50 text-emerald-600' },
    { label: 'Resolved', value: resolvedItems.length, icon: TrendingUp, color: 'bg-amber-50 text-amber-600' },
  ];

  return (
    <div>
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-3xl font-bold text-slate-900">Dashboard</h1>
          <p className="text-slate-500 mt-1">Manage your reported items and track matches</p>
        </div>
        <Link
          to="/app/report"
          className="px-5 py-2.5 rounded-xl bg-slate-900 text-white font-semibold hover:bg-slate-800 transition-colors flex items-center gap-2"
        >
          <Plus className="w-4 h-4" />
          Report item
        </Link>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-10">
        {stats.map((s) => (
          <div key={s.label} className="rounded-2xl border border-gray-200 bg-white p-5">
            <div className={`w-10 h-10 rounded-xl flex items-center justify-center mb-3 ${s.color}`}>
              <s.icon className="w-5 h-5" />
            </div>
            <p className="text-3xl font-bold text-slate-900">{s.value}</p>
            <p className="text-sm text-slate-500 mt-1">{s.label}</p>
          </div>
        ))}
      </div>

      {/* AI matches CTA */}
      <Link
        to="/app/matches"
        className="block rounded-2xl bg-gradient-to-r from-slate-900 to-slate-800 p-6 mb-10 hover:from-slate-800 hover:to-slate-700 transition-colors group"
      >
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-emerald-500 flex items-center justify-center">
              <Sparkles className="w-6 h-6 text-white" />
            </div>
            <div>
              <h3 className="text-white font-bold text-lg">Check AI Matches</h3>
              <p className="text-slate-300 text-sm">See if your lost items match anything found by others</p>
            </div>
          </div>
          <div className="text-white text-2xl group-hover:translate-x-1 transition-transform">→</div>
        </div>
      </Link>

      {/* Your items */}
      <div>
        <h2 className="text-xl font-bold text-slate-900 mb-4">Your items</h2>
        {loading ? (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {[1, 2, 3].map((i) => (
              <div key={i} className="rounded-2xl border border-gray-200 bg-white overflow-hidden animate-pulse">
                <div className="aspect-[4/3] bg-gray-100" />
                <div className="p-5 space-y-3">
                  <div className="h-5 bg-gray-100 rounded w-2/3" />
                  <div className="h-4 bg-gray-100 rounded w-1/2" />
                  <div className="h-3 bg-gray-100 rounded w-3/4" />
                </div>
              </div>
            ))}
          </div>
        ) : items.length === 0 ? (
          <div className="rounded-2xl border-2 border-dashed border-gray-200 p-12 text-center">
            <Package className="w-12 h-12 text-gray-300 mx-auto mb-4" />
            <h3 className="font-semibold text-slate-900 mb-1">No items reported yet</h3>
            <p className="text-slate-500 text-sm mb-4">Report a lost or found item to get started</p>
            <Link
              to="/app/report"
              className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-slate-900 text-white font-semibold hover:bg-slate-800 transition-colors"
            >
              <Plus className="w-4 h-4" />
              Report your first item
            </Link>
          </div>
        ) : (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {items.map((item) => (
              <ItemCard key={item.id} item={item} showStatus />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
